package com.strathub2.backend2.projection;


public interface TituloProjection {
    Long getId();
    String getNome();
    String GetDescricao();
}
