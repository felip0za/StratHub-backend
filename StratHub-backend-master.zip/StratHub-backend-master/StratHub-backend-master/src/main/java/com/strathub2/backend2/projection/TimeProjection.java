package com.strathub2.backend2.projection;


public interface TimeProjection {

    Long getId();
    String getNome();
    String getDescricao();

}