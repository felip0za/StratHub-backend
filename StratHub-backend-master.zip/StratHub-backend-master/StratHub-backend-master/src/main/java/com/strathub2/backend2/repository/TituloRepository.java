package com.strathub2.backend2.repository;

import com.strathub2.backend2.entity.Titulo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TituloRepository extends JpaRepository<Titulo, Long> {
}
