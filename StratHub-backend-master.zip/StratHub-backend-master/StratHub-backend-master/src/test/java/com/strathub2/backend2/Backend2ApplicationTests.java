package com.strathub2.backend2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Backend2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
